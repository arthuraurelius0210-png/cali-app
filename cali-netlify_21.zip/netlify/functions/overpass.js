const https = require('https');
const http = require('http');

function httpPost(urlStr, postData) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlStr);
    const lib = url.protocol === 'https:' ? https : http;
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
        'User-Agent': 'CALI-App/1.0'
      }
    };
    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if(res.statusCode >= 200 && res.statusCode < 300){
          try { resolve(JSON.parse(data)); }
          catch(e){ reject(new Error('JSON parse error')); }
        } else {
          reject(new Error('HTTP ' + res.statusCode));
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(20000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(postData);
    req.end();
  });
}

exports.handler = async function(event) {
  let query = null;
  if(event.queryStringParameters && event.queryStringParameters.query){
    query = event.queryStringParameters.query;
  }
  if (!query) {
    return { statusCode: 400, body: JSON.stringify({error: 'Missing query'}) };
  }

  const postData = 'data=' + encodeURIComponent(query);
  const servers = [
    'https://overpass-api.de/api/interpreter',
    'https://lz4.overpass-api.de/api/interpreter',
    'https://z.overpass-api.de/api/interpreter'
  ];

  for(const server of servers){
    try {
      const data = await httpPost(server, postData);
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify(data)
      };
    } catch(e) {
      console.log('Server failed:', server, e.message);
      continue;
    }
  }

  return { statusCode: 500, body: JSON.stringify({error: 'All servers failed'}) };
};
